#include "raylib.h"
#include <stdlib.h>
#include <time.h>
#include <stdio.h>

#define CELL_SIZE 20
#define SCREEN_WIDTH 1000
#define SCREEN_HEIGHT 1000
#define MAX_FRUITS 10
#define FRUIT_SIZE (2 * CELL_SIZE)
#define SKULL_SIZE (2 * CELL_SIZE)
#define HIGHSCORE_FILE "highscore.txt"

typedef enum { MENU, GAME, PAUSE, GAME_OVER } GameState;
typedef enum { APPLE, PINEAPPLE, WATERMELON, SKULL } FruitType;

typedef struct {
    Vector2 position;
    FruitType type;
} Fruit;

typedef struct {
    Vector2 position;
    Vector2 direction;
    int length;
    int capacity;
    Vector2 *body;
    int score;
    int glowTimer;
} Snake;

// High score variable
int highScore = 0;

// Load high score from file
void LoadHighScore(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file) {
        fscanf(file, "%d", &highScore);
        fclose(file);
    } else {
        highScore = 0;
    }
}

// Save high score to file
void SaveHighScore(const char *filename, int score) {
    FILE *file = fopen(filename, "w");
    if (file) {
        fprintf(file, "%d", score);
        fclose(file);
    }
}

void InitSnake(Snake *snake) {
    snake->position = (Vector2){SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2};
    snake->direction = (Vector2){CELL_SIZE, 0};
    snake->length = 3;
    snake->capacity = 16;
    snake->score = 0;
    snake->glowTimer = 0;
    if (snake->body) free(snake->body);
    snake->body = (Vector2*)malloc(snake->capacity * sizeof(Vector2));
    for (int i = 0; i < snake->length; i++) {
        snake->body[i] = (Vector2){snake->position.x - i * CELL_SIZE, snake->position.y};
    }
}

void MoveSnake(Snake *snake) {
    if (snake->length > snake->capacity) {
        snake->capacity *= 2;
        snake->body = (Vector2*)realloc(snake->body, snake->capacity * sizeof(Vector2));
    }
    for (int i = snake->length - 1; i > 0; i--) {
        snake->body[i] = snake->body[i - 1];
    }
    snake->position.x += snake->direction.x;
    snake->position.y += snake->direction.y;
    snake->body[0] = snake->position;
}

bool CheckCollision(Vector2 a, Vector2 b) {
    return (a.x == b.x && a.y == b.y);
}

void SpawnFruit(Fruit *fruit) {
    fruit->type = (FruitType)GetRandomValue(0, 2); // APPLE, PINEAPPLE, WATERMELON
    fruit->position.x = (GetRandomValue(0, (SCREEN_WIDTH - FRUIT_SIZE) / CELL_SIZE)) * CELL_SIZE;
    fruit->position.y = (GetRandomValue(0, (SCREEN_HEIGHT - FRUIT_SIZE) / CELL_SIZE)) * CELL_SIZE;
}

void SpawnSkull(Fruit *skull) {
    skull->type = SKULL;
    skull->position.x = (GetRandomValue(0, (SCREEN_WIDTH - SKULL_SIZE) / CELL_SIZE)) * CELL_SIZE;
    skull->position.y = (GetRandomValue(0, (SCREEN_HEIGHT - SKULL_SIZE) / CELL_SIZE)) * CELL_SIZE;
}

bool CheckFruitCollision(Vector2 snakeHead, Fruit *fruit, int size) {
    Rectangle fruitRect = { fruit->position.x, fruit->position.y, size, size };
    Rectangle snakeRect = { snakeHead.x, snakeHead.y, CELL_SIZE, CELL_SIZE };
    return CheckCollisionRecs(fruitRect, snakeRect);
}

bool CheckSelfCollision(Snake *snake) {
    for (int i = 1; i < snake->length; i++) {
        if (CheckCollision(snake->body[0], snake->body[i])) return true;
    }
    return false;
}

int GetFruitScore(FruitType type) {
    switch (type) {
        case APPLE: return 1;
        case PINEAPPLE: return 2;
        case WATERMELON: return 5;
        case SKULL: return -1;
        default: return 0;
    }
}

int main() {
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Snake.io");
    SetTargetFPS(60); // Keep high for smooth music
    srand(time(0));

    InitAudioDevice();
    Sound eatSound = LoadSound("soundeffect/cartoonbite.mp3");
    Sound gameOverSound = LoadSound("soundeffect/gameover.mp3");
    Music bgm = LoadMusicStream("soundeffect/game-music-loop-7.mp3");
    SetSoundVolume(eatSound, 2.0f);
    SetSoundVolume(gameOverSound, 4.0f);
    PlayMusicStream(bgm);

    LoadHighScore(HIGHSCORE_FILE);

    Snake snake = {0};
    Fruit fruits[MAX_FRUITS];
    Fruit skull, skull2, skull3;

    GameState state = MENU;
    int selectedLevel = 0;

    // For smooth music and independent snake speed
    float snakeMoveTimer = 0.0f;
    float snakeMoveInterval = 1.0f / 15.0f; // Level 1: 15 moves/sec

    InitSnake(&snake);
    for (int i = 0; i < MAX_FRUITS; i++) SpawnFruit(&fruits[i]);
    SpawnSkull(&skull);
    SpawnSkull(&skull2);

    float skullMoveTimer = 0.0f;
    const float SKULL_MOVE_INTERVAL = 4.0f;

    Texture2D appleTex = LoadTexture("apple.png");
    Texture2D pineappleTex = LoadTexture("pineapple.png");
    Texture2D watermelonTex = LoadTexture("watermelon.png");
    Texture2D skullTex = LoadTexture("Skull.png");
    Texture2D level1Bg = LoadTexture("map/level1map.png"); // Level 1 background
    Texture2D level2Bg = LoadTexture("map/level2map.png"); // Added level 2 background
    Texture2D level3Bg = LoadTexture("map/level3map.png"); // Level 3 background
    Texture2D level4Bg = LoadTexture("map/level4map.png"); // Level 4 background

    while (!WindowShouldClose()) {
        UpdateMusicStream(bgm);

        BeginDrawing();
        ClearBackground(RAYWHITE);

        if (state == MENU) {
            int fontSize = 50;
            const char *title = "GP SNAKE.IO";
            int textWidth = MeasureText(title, fontSize);
            DrawText(title, (SCREEN_WIDTH - textWidth) / 2, SCREEN_HEIGHT / 2 - 180, fontSize, DARKGREEN);

            DrawText("Choose a Level:", SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2 - 120, 30, BLACK);

            Rectangle level1Btn = { SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2 - 60, 200, 50 };
            Rectangle level2Btn = { SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2,      200, 50 };
            Rectangle level3Btn = { SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2 + 60, 200, 50 };
            Rectangle level4Btn = { SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2 + 120, 200, 50 };

            // Draw level buttons with lock logic
            Color btnColor1 = CheckCollisionPointRec(GetMousePosition(), level1Btn) ? RED : LIGHTGRAY;
            Color btnColor2 = (highScore >= 100 && CheckCollisionPointRec(GetMousePosition(), level2Btn)) ? GREEN : LIGHTGRAY;
            Color btnColor3 = (highScore >= 300 && CheckCollisionPointRec(GetMousePosition(), level3Btn)) ? PURPLE : LIGHTGRAY;
            Color btnColor4 = (highScore >= 500 && CheckCollisionPointRec(GetMousePosition(), level4Btn)) ? BLUE : LIGHTGRAY;

            // Draw all level buttons
            DrawRectangleRec(level1Btn, btnColor1);
            DrawRectangleRec(level2Btn, btnColor2);
            DrawRectangleRec(level3Btn, btnColor3);
            DrawRectangleRec(level4Btn, btnColor4);

            DrawText("Level 1 ",   level1Btn.x + 30, level1Btn.y + 15, 20, BLACK);
            DrawText("Level 2 ", level2Btn.x + 30, level2Btn.y + 15, 20, (highScore >= 100) ? BLACK : GRAY);
            DrawText("Level 3 ",   level3Btn.x + 30, level3Btn.y + 15, 20, (highScore >= 300) ? BLACK : GRAY);
            DrawText("Level 4 ",   level4Btn.x + 30, level4Btn.y + 15, 20, (highScore >= 500) ? BLACK : GRAY);

            if (highScore < 100)
                DrawText("LOCKED", level2Btn.x + 120, level2Btn.y + 15, 20, GRAY);
            if (highScore < 300)
                DrawText("LOCKED", level3Btn.x + 120, level3Btn.y + 15, 20, GRAY);
            if (highScore < 500)
                DrawText("LOCKED", level4Btn.x + 120, level4Btn.y + 15, 20, GRAY);

            // Move the high score text lower so it doesn't cover Level 4
            DrawText(TextFormat("High Score: %d", highScore), SCREEN_WIDTH / 2 - 80, SCREEN_HEIGHT / 2 + 190, 25, DARKBLUE);

            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                Vector2 mouse = GetMousePosition();

                if (CheckCollisionPointRec(mouse, level1Btn)) {
                    selectedLevel = 1;
                    snakeMoveInterval = 1.0f / 15.0f;
                    InitSnake(&snake);
                    SpawnSkull(&skull);
                    state = GAME;
                }
                if (highScore >= 100 && CheckCollisionPointRec(mouse, level2Btn)) {
                    selectedLevel = 2;
                    snakeMoveInterval = 1.0f / 18.0f;
                    InitSnake(&snake);
                    SpawnSkull(&skull);
                    state = GAME;
                }
                if (highScore >= 300 && CheckCollisionPointRec(mouse, level3Btn)) {
                    selectedLevel = 3;
                    snakeMoveInterval = 1.0f / 25.0f;
                    InitSnake(&snake);
                    SpawnSkull(&skull);
                    SpawnSkull(&skull2);
                    state = GAME;
                }
                if (highScore >= 500 && CheckCollisionPointRec(mouse, level4Btn)) {
                    selectedLevel = 4;
                    snakeMoveInterval = 1.0f / 30.0f;
                    InitSnake(&snake);
                    SpawnSkull(&skull);
                    SpawnSkull(&skull2);
                    SpawnSkull(&skull3);
                    state = GAME;
                }
            }
        } else if (state == GAME) {
            // Draw level 2 background first
            if (selectedLevel == 1) {
                Rectangle src = {0, 0, (float)level1Bg.width, (float)level1Bg.height};
                Rectangle dest = {0, 0, (float)SCREEN_WIDTH, (float)SCREEN_HEIGHT};
                DrawTexturePro(level1Bg, src, dest, (Vector2){0, 0}, 0.0f, WHITE);
            } 
            else if (selectedLevel == 2) {
                Rectangle src = {0, 0, (float)level2Bg.width, (float)level2Bg.height};
                Rectangle dest = {0, 0, (float)SCREEN_WIDTH, (float)SCREEN_HEIGHT};
                DrawTexturePro(level2Bg, src, dest, (Vector2){0, 0}, 0.0f, WHITE);
            } 
            else if (selectedLevel == 3) {
                Rectangle src = {0, 0, (float)level3Bg.width, (float)level3Bg.height};
                Rectangle dest = {0, 0, (float)SCREEN_WIDTH, (float)SCREEN_HEIGHT};
                DrawTexturePro(level3Bg, src, dest, (Vector2){0, 0}, 0.0f, WHITE);
            } 
            else if (selectedLevel == 4) {
                Rectangle src = {0, 0, (float)level4Bg.width, (float)level4Bg.height};
                Rectangle dest = {0, 0, (float)SCREEN_WIDTH, (float)SCREEN_HEIGHT};
                DrawTexturePro(level4Bg, src, dest, (Vector2){0, 0}, 0.0f, WHITE);
            }

            if (IsKeyPressed(KEY_P)) {
                state = PAUSE;
            }
            if (IsKeyPressed(KEY_UP) && snake.direction.y == 0) snake.direction = (Vector2){0, -CELL_SIZE};
            if (IsKeyPressed(KEY_DOWN) && snake.direction.y == 0) snake.direction = (Vector2){0, CELL_SIZE};
            if (IsKeyPressed(KEY_LEFT) && snake.direction.x == 0) snake.direction = (Vector2){-CELL_SIZE, 0};
            if (IsKeyPressed(KEY_RIGHT) && snake.direction.x == 0) snake.direction = (Vector2){CELL_SIZE, 0};

            // Auto level up based on score
            if (selectedLevel == 1 && snake.score >= 100) {
                selectedLevel = 2;
                snakeMoveInterval = 1.0f / 18.0f;
            }
            if (selectedLevel == 2 && snake.score >= 300) {
                selectedLevel = 3;
                snakeMoveInterval = 1.0f / 25.0f;
                SpawnSkull(&skull2);
            }
            if (selectedLevel == 3 && snake.score >= 500) {
                selectedLevel = 4;
                snakeMoveInterval = 1.0f / 30.0f;
                SpawnSkull(&skull3);
            }

            // Move snake only when timer passes interval
            snakeMoveTimer += GetFrameTime();
            if (snakeMoveTimer >= snakeMoveInterval) {
                snakeMoveTimer = 0.0f;

                MoveSnake(&snake);

                if (snake.position.x < 0) snake.position.x = SCREEN_WIDTH - CELL_SIZE;
                if (snake.position.x >= SCREEN_WIDTH) snake.position.x = 0;
                if (snake.position.y < 0) snake.position.y = SCREEN_HEIGHT - CELL_SIZE;
                if (snake.position.y >= SCREEN_HEIGHT) snake.position.y = 0;

                // Check collision with both skulls on level 3
                int hitSkull = CheckFruitCollision(snake.body[0], &skull, SKULL_SIZE);
                if (selectedLevel >= 3)
                    hitSkull = hitSkull || CheckFruitCollision(snake.body[0], &skull2, SKULL_SIZE);
                if (selectedLevel == 4)
                    hitSkull = hitSkull || CheckFruitCollision(snake.body[0], &skull3, SKULL_SIZE);

                if (hitSkull) {
                    PlaySound(gameOverSound);
                    state = GAME_OVER;
                }

                for (int i = 0; i < MAX_FRUITS; i++) {
                    if (CheckFruitCollision(snake.body[0], &fruits[i], FRUIT_SIZE)) {
                        PlaySound(eatSound);
                        snake.score += GetFruitScore(fruits[i].type);
                        snake.length++;
                        snake.glowTimer = 5;
                        SpawnFruit(&fruits[i]);
                    }
                }

                if (CheckSelfCollision(&snake)) {
                    PlaySound(gameOverSound);
                    state = GAME_OVER;
                }
            }

            skullMoveTimer += GetFrameTime();
            if (selectedLevel == 4 && skullMoveTimer >= SKULL_MOVE_INTERVAL) {
                skullMoveTimer = 0.0f;
                SpawnSkull(&skull);
                SpawnSkull(&skull2);
                SpawnSkull(&skull3);
            } else if (selectedLevel == 3 && skullMoveTimer >= SKULL_MOVE_INTERVAL) {
                skullMoveTimer = 0.0f;
                SpawnSkull(&skull);
                SpawnSkull(&skull2);
            } else if (skullMoveTimer >= SKULL_MOVE_INTERVAL) {
                skullMoveTimer = 0.0f;
                SpawnSkull(&skull);
            }

            Color snakeColor = (snake.glowTimer > 0) ? GOLD : GREEN;
            Color headColor = (snake.glowTimer > 0) ? ORANGE : DARKGREEN;
            if (snake.glowTimer > 0) snake.glowTimer--;

            for (int i = 0; i < snake.length; i++) {
                DrawRectangleV(snake.body[i], (Vector2){CELL_SIZE, CELL_SIZE}, (i == 0) ? headColor : snakeColor);
            }

            for (int i = 0; i < MAX_FRUITS; i++) {
                Texture2D tex;
                switch (fruits[i].type) {
                    case APPLE: tex = appleTex; break;
                    case PINEAPPLE: tex = pineappleTex; break;
                    case WATERMELON: tex = watermelonTex; break;
                    default: tex = appleTex; break;
                }
                Rectangle src = { 0, 0, (float)tex.width, (float)tex.height };
                Rectangle dest = { fruits[i].position.x, fruits[i].position.y, FRUIT_SIZE, FRUIT_SIZE };
                DrawTexturePro(tex, src, dest, (Vector2){0, 0}, 0.0f, WHITE);
            }

            Rectangle src = { 0, 0, (float)skullTex.width, (float)skullTex.height };
            Rectangle dest = { skull.position.x, skull.position.y, SKULL_SIZE, SKULL_SIZE };
            DrawTexturePro(skullTex, src, dest, (Vector2){0, 0}, 0.0f, WHITE);

            if (selectedLevel >= 3) {
                Rectangle dest2 = { skull2.position.x, skull2.position.y, SKULL_SIZE, SKULL_SIZE };
                DrawTexturePro(skullTex, src, dest2, (Vector2){0, 0}, 0.0f, WHITE);
            }
            if (selectedLevel == 4) {
                Rectangle dest3 = { skull3.position.x, skull3.position.y, SKULL_SIZE, SKULL_SIZE };
                DrawTexturePro(skullTex, src, dest3, (Vector2){0, 0}, 0.0f, WHITE);
            }

            DrawText(TextFormat("Score: %d", snake.score), 10, 10, 20, PURPLE);
            DrawText(TextFormat("High Score: %d", highScore), 10, 40, 20, PURPLE);
            DrawText(TextFormat("Level: %d", selectedLevel), 10, 70, 20, PURPLE);

        } else if (state == PAUSE) {
            DrawText("PAUSED", SCREEN_WIDTH / 2 - 80, SCREEN_HEIGHT / 2 - 40, 50, ORANGE);
            DrawText("Press P to Resume", SCREEN_WIDTH / 2 - 120, SCREEN_HEIGHT / 2 + 20, 30, DARKGRAY);
            DrawText("Press M for Menu", SCREEN_WIDTH / 2 - 120, SCREEN_HEIGHT / 2 + 60, 30, DARKGRAY);

            if (IsKeyPressed(KEY_P)) state = GAME;
            if (IsKeyPressed(KEY_M)) state = MENU;

        } else if (state == GAME_OVER) {
            DrawText(" GAME OVER ", SCREEN_WIDTH / 2 - 140, SCREEN_HEIGHT / 2 - 40, 40, RED);
            DrawText(TextFormat("Your Score: %d", snake.score), SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2 + 10, 25, BLACK);

            if (snake.score > highScore) {
                highScore = snake.score;
                SaveHighScore(HIGHSCORE_FILE, highScore);
                DrawText("NEW HIGH SCORE!", SCREEN_WIDTH / 2 - 120, SCREEN_HEIGHT / 2 - 80, 30, GOLD);
            }

            DrawText(TextFormat("High Score: %d", highScore), SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2 + 40, 25, DARKGRAY);
            DrawText("Press R to Restart or M for Menu", SCREEN_WIDTH / 2 - 160, SCREEN_HEIGHT / 2 + 80, 20, GRAY);

            if (IsKeyPressed(KEY_R)) {
                selectedLevel = 1;
                snakeMoveInterval = 1.0f / 15.0f;
                InitSnake(&snake);
                for (int i = 0; i < MAX_FRUITS; i++) SpawnFruit(&fruits[i]);
                SpawnSkull(&skull);
                SpawnSkull(&skull2);
                snakeMoveTimer = 0;
                skullMoveTimer = 0;
                state = GAME;
            }
            if (IsKeyPressed(KEY_M)) {
                state = MENU;
            }
        }

        EndDrawing();
    }

    UnloadTexture(appleTex);
    UnloadTexture(pineappleTex);
    UnloadTexture(watermelonTex);
    UnloadTexture(skullTex);
    UnloadTexture(level1Bg); // Unload level 1 background
    UnloadTexture(level2Bg); // Unload level 2 background
    UnloadTexture(level3Bg); // Unload level 3 background
    UnloadTexture(level4Bg); // Unload level 4 background
    if (snake.body) free(snake.body);
    UnloadSound(eatSound);
    UnloadSound(gameOverSound);
    UnloadMusicStream(bgm);
    CloseAudioDevice();
    CloseWindow();
    return 0;
}
